﻿/* C6003
 * CIS 200-01
 * Prog0
 * This application tests the address class, parcel class, and letter class to show calculated cost and origin and destination 
 * addresses of created objects in the test application.
 * */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    class Program
    {
        static void Main(string[] args)
        {
            //Intialize new list from class Parcel
            List<Parcel> parcelList = new List<Parcel>();

            //Creating 4 new address objects from class Address
            Address address1 = new Address("Bill Murray", "1801 Century Park West","","Los Angeles","California",90067);
            Address address2 = new Address("Willy B Cash Money", "Got Money Lane", "Apt 302", "San Franscisco", "California", 94105);
            Address address3 = new Address("Jon Snow", "Cold Front Circle", "Apt 101", "North Wall", "Westeros", 019283);
            Address address4 = new Address("Sarah Palin", "1140 W Parks Hwy", "", "Wasilla", "Alaska", 99654);

            //Creating 3 new letter objects from class letter referencing the address objects created previously
            Letter letter1 = new Letter(address1, address3, 2.25M);
            Letter letter2 = new Letter(address2, address4, 3.75M);
            Letter letter3 = new Letter(address1, address4, 4.50M);

            //Add each letter to the list
            parcelList.Add(letter1);
            parcelList.Add(letter2);
            parcelList.Add(letter3);

            //Foreach loop to display each letter added onto a Console Application 
            foreach (Parcel letter in parcelList)
                Console.WriteLine(letter);
            

        }
    }
}
