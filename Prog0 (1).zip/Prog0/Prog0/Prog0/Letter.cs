﻿//Letter class setting the cost for each parcel derived from the abstract parcel class
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class Letter : Parcel
    {
        private decimal _fixedCost; //Fixed Cost of Parcel
        
        //Precondition: none
        //Postcondition: the Letter has been initalized with FixedCost and the origin and destination addresses from
        //the base class.
        public Letter(Address origin, Address destination, decimal fixedCost) : base(origin, destination)
        {
            FixedCost = fixedCost;
        }

        //Precondition: fixed cost must be greater than or equal to zero.
        //Postcondition: the fixed cost has been set to a specified value
        private decimal FixedCost
        {
            get
            {
                return _fixedCost;
            }
            set
            {
                if (value >= 0)    //validation for no negative costs
                    _fixedCost = value;
            }
        }

        //Precondition: none
        //Postcondition: CalcCost has been set to a specified value
        public override decimal CalcCost()
        {
            return FixedCost;
        }

        //Precondition: none
        //Postcondition: a string is returned presenting destination address and origin address along with the cost
        public override string ToString()
        {           
            return string.Format("{0}\nCalculated Cost: {1:c}", base.ToString(), FixedCost);            
        }
    }
        
    }

