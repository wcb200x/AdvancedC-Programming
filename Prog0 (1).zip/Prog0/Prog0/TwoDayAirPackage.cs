﻿//This class creates the TwoDayAirPackage class derived from the abstract class AirPackage. Creates a TwoDayAirPackage object
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class TwoDayAirPackage : AirPackage
    {


        public enum Delivery { Early, Saver };
        //precondition: length >0, width >0, weight >0, height >0
        //postcondition: two day air package has been created with specified values for length, width, weight, height
        public TwoDayAirPackage(Address originAddress, Address destAddress, double length, double width, double weight, double height, Delivery type)
            : base(originAddress, destAddress, length, width, height, weight)
        {
            DeliveryType = type;
        }
        
        public Delivery DeliveryType
        {
            //precondition:none
            //postcondition: Delivery type is returned
            get;
            //precondition: must be early type or saver type
            //postcondition: early or saver value is returned
            set;
        }
        //precondition: none
        //postcondition: the specified two day air package has been specified with a cost
        public override decimal CalcCost()
        {
            const decimal discount_Rate = .90M; //constant variable for discount rate of saver package
            const decimal dim_Rate = .25M; //size constant variable
            const decimal weight_Rate = .25M; //weight constant variable
            decimal lengthDecimal = Convert.ToDecimal(Length);
            decimal widthDecimal = Convert.ToDecimal(Width);
            decimal heightDecimal = Convert.ToDecimal(Height);
            decimal weightDecimal = Convert.ToDecimal(Weight);
            decimal baseCost = (dim_Rate * (lengthDecimal + widthDecimal + heightDecimal)) +( weight_Rate * (weightDecimal));
            
            if (DeliveryType == Delivery.Saver)
                return baseCost * discount_Rate;
            else
                return baseCost;

        }
        //precondition: none
        //postcondition: a string with the two day air package information is returned
        public override string ToString()
        {
            return "Two Day Air Package" + Environment.NewLine + "Delivery Type:" + DeliveryType.ToString() + Environment.NewLine + base.ToString();

        }
    }
}
