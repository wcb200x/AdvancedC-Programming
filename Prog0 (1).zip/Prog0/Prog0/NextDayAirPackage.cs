﻿//Creates NextDayAirPackage class and creates an object from user input
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class NextDayAirPackage:AirPackage
    {
     
        //constructor for NextDayAirPackage and its base class
        //precondition: length>=0, width >=0, height >=0, weight >=0, expressFee >=0
        //postcondition: nextdayairpackage is created with origin address, destination address, length, width, height, weight, and expressFee
        // having specified values.
        public NextDayAirPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight, 
            decimal expressFee) : base (originAddress, destAddress, length, width, height, weight)
        {
            //no new fields initialized
        }
        
        public decimal ExpressFee
        {
            //precondition: none
            //postcondition: initialize ExpressFee
            get;
            
                
        }
        //precondition: none
        //postcondition: NextDayAirPackage cost has been returned
        public override decimal CalcCost()
        {
            const decimal dim_Rate = .40M;
            const decimal weight_Rate = .30M;
            decimal lengthDecimal = Convert.ToDecimal(Length);
            decimal widthDecimal = Convert.ToDecimal(Width);
            decimal heightDecimal = Convert.ToDecimal(Height);
            decimal weightDecimal = Convert.ToDecimal(Weight);
            decimal weightCost = .25M * (weightDecimal);
            decimal sizeCost = .25M * (lengthDecimal + widthDecimal + heightDecimal);
                
            //if statement to determine package weight and size for calculation
            decimal baseCost = dim_Rate * (lengthDecimal + widthDecimal + heightDecimal) + weight_Rate * (weightDecimal) + ExpressFee;
            if(IsLarge() && IsHeavy())
            {
                return baseCost + weightCost + sizeCost;
            }
            else if (IsLarge())
            {
                return baseCost + sizeCost;
            }
            else if (IsHeavy())
            {
                return baseCost + weightCost;
            }
            else
            {
                return baseCost;
            }
        }
        //precondition: none
        //postcondition: a string with next day air package information has been returned
        public override String ToString()
        {
            return "Next Day Air Package" + Environment.NewLine + base.ToString() + Environment.NewLine;
        }
    }
}
