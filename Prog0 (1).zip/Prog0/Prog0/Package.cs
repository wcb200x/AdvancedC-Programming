﻿//Package is an abstract class that acts as a base class for GroundPackage and AirPackage
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public abstract class Package : Parcel
{
    //backing fields
    private double _length; 
    private double _width;
    private double _height;
    private double _weight;
    //Constructor for public class Package 
    //precondition: length >0, width >0, height >0, weight >0
    //postcondition: Package is created with length, width, height, and weight
    public Package(Address originAddress, Address destAddress, double length, double width, double height, double weight) :
        base(originAddress, destAddress)
    {
        Length = length; //instantiated property value Length
        Width = width; //instantiated property value Width
        Height = height; //instantiated property value Height
        Weight = weight; //instantiated property value Weight
    }
     
    public double Length
    {
        //precondition:none
        //postcondition: return length value 
        get
        {
            return _length;
        }
        //precondition: length must be a non-negative integer
        //postcondition: Length is set to a specified value
        set
        {
            if (value >= 0)
                _length = value;
            else
                throw new ArgumentOutOfRangeException("Inches", value, "Inches of Package must be greater than or equal to zero");
        }
    }
    public double Width
    {
        //precondition: none
        //postcondition: returns width value
        get
        {
            return _width;
        }
        //precondition: must be a non-negative integer value
        //postcondition: Width is set to a specified value
        set
        {
            if (value >= 0)
                _width = value;
            else
                throw new ArgumentOutOfRangeException("Width", value, "Width of Package must be greater than or equal to zero");
        }
    }
    public double Height
    {
        //precondition: none
        //postcondtion: returns height value
        get
        {
            return _height;
        }
        set
            //precondition: must be a non-negative integer value
            //postcondition: Height is set to a specified value
        {
            if (value >= 0)
                _height = value;
            else
                throw new ArgumentOutOfRangeException("Height", value, "Height of Package must be greater than or equal to zero");
        }
    }
    public double Weight
    {
        //precondition: none
        //postcondition: returns weight value
        get
        {
            return _weight;
        }
        //precondition: must be a non-negative integer value
        //postcondition: Weight is set to a specified value
        set
        {
            if (value >= 0)
                _weight = value;
            else
                throw new ArgumentOutOfRangeException("Weight", value, "Weight of the Package must be greater than or equal to zero");
        }
    }
    //precondition: none
    //postcondition: initiliazes ToString and returns length, width, height, weight, and base in a tostring 
    public override String ToString()
    {
        return string.Format("Length:{0}{4}Width:{1}{4}Height:{2}{4}Weight:{3}{4}{5}", Length, Width, Height, Weight, Environment.NewLine, base.ToString());
    }
}

    

