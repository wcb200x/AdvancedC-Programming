﻿//Creates a GroundPackage class and object
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class GroundPackage : Package
    {
        //precondition: length >=0, weight >=0, height >=0, weight >=0, 
        //postcondition: ground package is created with specified values for origin address, destination address, length, width, height,
        //and weight.
        public GroundPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight) : base (originAddress, destAddress, length, width, height, weight)
        {
            //no new data to intialize
        }

        public int ZoneDist
        {
            // Precondition:  None
            // Postcondition: The ground package's zone distance is returned.
            //                The zone distance is the positive difference between the
            //                first digit of the origin zip code and the first
            //                digit of the destination zip code.
            get
            {
                const int zipDivisor = 10000; //constant variable used to extract the first digit
               return Math.Abs(OriginAddress.Zip / zipDivisor - DestinationAddress.Zip / zipDivisor);
            }
        }

        //precondition: none
        //postcondition: the specified ground package cost has been returned
        public override decimal CalcCost()
        {        
            const decimal dim_Rate = .20M; //constant variable holding size percent factor
            const decimal weight_Rate = .05M; //constant variable holding weight percent factor
            decimal lengthDecimal = Convert.ToDecimal(Length);
            decimal widthDecimal = Convert.ToDecimal(Width);
            decimal heightDecimal = Convert.ToDecimal(Height);
            decimal weightDecimal = Convert.ToDecimal(Weight);
            decimal calculatedCost = (dim_Rate * (lengthDecimal + widthDecimal + heightDecimal) + weight_Rate * (ZoneDist + 1) * weightDecimal);
            return calculatedCost;
        }
        //precondition: none
        //postcondition: a string with the ground package information has been returned
        public override string ToString()
        {
            return string.Format("Ground Package:{2}{1}{2}Zone Distance: {0}{2}{2}", ZoneDist, base.ToString(), Environment.NewLine);

        }
    }
}