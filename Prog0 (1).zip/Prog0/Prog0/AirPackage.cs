﻿//Abstract class that is the base class for TwoDayAirPackage and NextDayAirPackage
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



    public abstract class AirPackage : Package
    {
    const double weightLimit = 75; //constant variable to hold weight limit for packages
    const double sizeLimit = 100; //constant varaible to hold size limit for packages
    //constructor for class AirPackage
    //precondition: length >0, width>0, height >0, weight >0
    //postcondition: air package has been created with length, width, height, and weight
        public AirPackage(Address originAddress, Address destAddress, double length, double width, double height, double weight) : base(originAddress, destAddress, length, width, height, weight)
    {
        //no new values instantiated
    }

   //precondition: none
   //postcondition: IsHeavy is set to a specified value
    public bool IsHeavy()
    {
        bool heavy = true; //variable to hold true statement
        bool light = false; //varaible to hold false statement
        if (Weight >=0 && Weight >= weightLimit)
            return heavy;
        else
            return light;
    }
    //precondition: positive non-negative integer
    //postcondition: IsLarge is set to a specified value
    public bool IsLarge()
    {
        bool large = true; //variable to hold true statement 
        bool small = false; //variable to hold false statement 
        if ((Length + Width + Height) >= sizeLimit && (Length + Width + Height) >=0)
            return large;
        else
            return small;     
        
    }
    //precondition: none
    //postcondition: a string with the air package information is returned
    public override string ToString()
    {
        return "Large Package:"+ IsLarge().ToString() + Environment.NewLine + "Heavy Package:" + IsHeavy().ToString() + Environment.NewLine + base.ToString();
    }





}

