﻿// Program 1B
// CIS 200-01/76
// Fall 2016
// Due: 10/17/2016
// By: C6003

// File: TestParcels.cs
// This is a simple, console application designed to exercise the Parcel hierarchy.
// It creates several different Parcels and prints them.
//This test also creates results from different LINQ queries in order to categorize data based on 
//specifications made in the queries.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Prog1
{
    class TestParcels
    {
        // Precondition:  None
        // Postcondition: Parcels have been created and displayed
        static void Main(string[] args)
        {
            // Test Data - Magic Numbers OK
            Address a1 = new Address("John Smith", "123 Any St.", "Apt. 45",
                "Louisville", "KY", 40202); // Test Address 1
            Address a2 = new Address("Jane Doe", "987 Main St.", "",
                "Beverly Hills", "CA", 90210); // Test Address 2
            Address a3 = new Address("James Kirk", "654 Roddenberry Way", "Suite 321",
                "El Paso", "TX", 79901); // Test Address 3
            Address a4 = new Address("John Crichton", "678 Pau Place", "Apt. 7",
                "Portland", "ME", 04101); // Test Address 4
            Address a5 = new Address("Frank Sinatra", "1274 Broadway Blvd", "Apt 509",
             "New York", "NY", 10037); //Test Address 5
            Address a6 = new Address("Cindy Brown", "132 Harrodsburg Rd", "",
                "Harrodsburg", "KY", 40330);
            Address a7 = new Address("Johnny B. Goode", "696 Rock N' Roll Plaza,", "Apt 66",
                "Las Vegas", "NV", 89101);
            Address a8 = new Address("Taylor Sumnter", "912 Circular Cir", "",
                "Lexington", "KY", 40502);
            Letter letter1 = new Letter(a1, a2, 3.95M);                            // Letter test object
            Letter letter2 = new Letter(a2, a6, 2.95M);                            // Letter test object
            GroundPackage gp1 = new GroundPackage(a3, a4, 14, 10, 5, 12.5);        // Ground test object
            GroundPackage gp2 = new GroundPackage(a8, a5, 20.7, 24.8, 55.8, 45.3); //Ground test object
            NextDayAirPackage ndap1 = new NextDayAirPackage(a1, a3, 25, 15, 15,    // Next Day test object
                85, 7.50M);
            NextDayAirPackage ndap2 = new NextDayAirPackage(a3, a7, 30.2, 39.5, 26.7, 30.4, 4.5M); //Next day test object
            NextDayAirPackage ndap3 = new NextDayAirPackage(a4, a6, 43.1, 43.2, 56.2, 23.1, 8.95M); //Next Day test object
            TwoDayAirPackage tdap1 = new TwoDayAirPackage(a4, a1, 46.5, 39.5, 28.0, // Two Day test object
                80.5, TwoDayAirPackage.Delivery.Saver);
            TwoDayAirPackage tdap2 = new TwoDayAirPackage(a1, a8, 29.7, 40.2, 60.1, //Two Day test object
                90.2, TwoDayAirPackage.Delivery.Early);
            TwoDayAirPackage tdap3 = new TwoDayAirPackage(a3, a4, 45.2, 32.4, 56.7, //Two Day test object
                32.1, TwoDayAirPackage.Delivery.Saver);
            List<Parcel> parcels;      // List of test parcels

            parcels = new List<Parcel>();

            parcels.Add(letter1); // Populate list
            parcels.Add(gp1);
            parcels.Add(ndap1);
            parcels.Add(tdap1);
            parcels.Add(tdap2);
            parcels.Add(tdap3);
            parcels.Add(ndap2);
            parcels.Add(ndap3);
            parcels.Add(gp2);
            parcels.Add(letter2);

            Console.WriteLine("Original List:");
            Console.WriteLine("====================");
            foreach (Parcel p in parcels)
            {
                Console.WriteLine(p);
                Console.WriteLine("====================");
            }
            //LINQ QUERY FOR ORDERING BY DESTINATION ZIP CODE
          
            var destAddress =
                from dest in parcels
                orderby dest.DestinationAddress.Zip descending
                select new { dest.DestinationAddress };
            Console.WriteLine("SORTED BY DESTINATION ZIP CODE");
            Console.WriteLine("==========================================");

            //FOREACH LOOP TO OUTPUT RESULTS OF LINQ QUERY ONTO A CONSOLE APPLICATION
    
            foreach(var element in destAddress)
            {
                Console.WriteLine("{0}", element.DestinationAddress);
                Console.WriteLine("--------------------------------------");
            }

            //LINQ QUERY FOR ORDERING BY COST

            var sortedByCost =
                from cost in parcels
                orderby cost.CalcCost()
                select cost;
            Console.WriteLine("SORTED BY COST");
            Console.WriteLine("==========================================");

            //FOREACH LOOP TO OUTPUT RESULTS OF LINQ QUERY ONTO A CONSOLE APPLICATION

            foreach(var element in sortedByCost)
            {
                Console.WriteLine(element);
                Console.WriteLine("--------------------------------------");
            }
            //LINQ QUERY FOR ORDERING BY PACKAGE TYPE AND COST

            var sortedByTypeandCost =
                from type in parcels
                orderby type.GetType().ToString() ascending, type.CalcCost() descending
                select new { Type = type.GetType(), Cost = type.CalcCost() };
            Console.WriteLine("SORTED BY TYPE AND COST");
            Console.WriteLine("===========================================");

            //FOREACH LOOP TO OUTPUT RESULTS OF LINQ QUERY ONTO A CONSOLE APPLICATION

            foreach(var element in sortedByTypeandCost)
            {
                Console.WriteLine("{0} {1:c}", element.Type, element.Cost );
                Console.WriteLine("--------------------------------------");
            }
            //LINQ QUERY ORDERING BY AIRPACKAGE WEIGHT

            var sortedAirPackage =
                from pack in parcels
                let airPack = pack as AirPackage //new variable airpack is set to a specified value
                where (airPack != null) && airPack.IsHeavy()
                orderby airPack.Weight descending
                select pack;
                
            Console.WriteLine("SORTED BY AIRPACKAGE WEIGHT");
            Console.WriteLine("===========================================");

            //FOREACH LOOP TO OUTPUT RESULTS OF LINQ QUERY ONTO A CONSOLE APPLICATION

            foreach (var element in sortedAirPackage)
            {
                Console.WriteLine(element);
                Console.WriteLine("---------------------------------------");
            }

            Pause();
       }

        // Precondition:  None
        // Postcondition: Pauses program execution until user presses Enter and
        //                then clears the screen
        public static void Pause()
        {
            Console.WriteLine("Press Enter to Continue...");
            Console.ReadLine();

            Console.Clear(); // Clear screen
        }
    }
}
