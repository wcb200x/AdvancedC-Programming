﻿namespace UPVApp
{
    partial class AddressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.customerNameText = new System.Windows.Forms.TextBox();
            this.customerAddressText = new System.Windows.Forms.TextBox();
            this.customerOptionalText = new System.Windows.Forms.TextBox();
            this.cityText = new System.Windows.Forms.TextBox();
            this.stateComboBox1 = new System.Windows.Forms.ComboBox();
            this.nameLabel = new System.Windows.Forms.Label();
            this.addressLabel = new System.Windows.Forms.Label();
            this.cityLabel = new System.Windows.Forms.Label();
            this.stateLabel = new System.Windows.Forms.Label();
            this.zipLabel = new System.Windows.Forms.Label();
            this.zipCodeText = new System.Windows.Forms.TextBox();
            this.addAddressButton = new System.Windows.Forms.Button();
            this.cancelButton = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider4 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider5 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).BeginInit();
            this.SuspendLayout();
            // 
            // customerNameText
            // 
            this.customerNameText.Location = new System.Drawing.Point(81, 15);
            this.customerNameText.Name = "customerNameText";
            this.customerNameText.Size = new System.Drawing.Size(144, 20);
            this.customerNameText.TabIndex = 0;
            this.customerNameText.Validating += new System.ComponentModel.CancelEventHandler(this.customerNameText_Validating);
            this.customerNameText.Validated += new System.EventHandler(this.customerNameText_Validated);
            // 
            // customerAddressText
            // 
            this.customerAddressText.Location = new System.Drawing.Point(81, 41);
            this.customerAddressText.Name = "customerAddressText";
            this.customerAddressText.Size = new System.Drawing.Size(144, 20);
            this.customerAddressText.TabIndex = 1;
            this.customerAddressText.Validating += new System.ComponentModel.CancelEventHandler(this.customerAddressText_Validating);
            this.customerAddressText.Validated += new System.EventHandler(this.customerAddressText_Validated);
            // 
            // customerOptionalText
            // 
            this.customerOptionalText.Location = new System.Drawing.Point(81, 67);
            this.customerOptionalText.Name = "customerOptionalText";
            this.customerOptionalText.Size = new System.Drawing.Size(144, 20);
            this.customerOptionalText.TabIndex = 2;
            // 
            // cityText
            // 
            this.cityText.Location = new System.Drawing.Point(81, 93);
            this.cityText.Name = "cityText";
            this.cityText.Size = new System.Drawing.Size(144, 20);
            this.cityText.TabIndex = 3;
            this.cityText.Validating += new System.ComponentModel.CancelEventHandler(this.cityText_Validating);
            this.cityText.Validated += new System.EventHandler(this.cityText_Validated);
            // 
            // stateComboBox1
            // 
            this.stateComboBox1.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.stateComboBox1.FormattingEnabled = true;
            this.stateComboBox1.Items.AddRange(new object[] {
            "KY",
            "TN",
            "FL",
            "CA",
            "NY",
            "HA"});
            this.stateComboBox1.Location = new System.Drawing.Point(81, 119);
            this.stateComboBox1.Name = "stateComboBox1";
            this.stateComboBox1.Size = new System.Drawing.Size(144, 21);
            this.stateComboBox1.TabIndex = 4;
            this.stateComboBox1.Validating += new System.ComponentModel.CancelEventHandler(this.stateComboBox1_Validating);
            this.stateComboBox1.Validated += new System.EventHandler(this.stateComboBox1_Validated);
            // 
            // nameLabel
            // 
            this.nameLabel.AutoSize = true;
            this.nameLabel.Location = new System.Drawing.Point(37, 15);
            this.nameLabel.Name = "nameLabel";
            this.nameLabel.Size = new System.Drawing.Size(38, 13);
            this.nameLabel.TabIndex = 5;
            this.nameLabel.Text = "Name:";
            // 
            // addressLabel
            // 
            this.addressLabel.AutoSize = true;
            this.addressLabel.Location = new System.Drawing.Point(27, 41);
            this.addressLabel.Name = "addressLabel";
            this.addressLabel.Size = new System.Drawing.Size(48, 13);
            this.addressLabel.TabIndex = 6;
            this.addressLabel.Text = "Address:";
            // 
            // cityLabel
            // 
            this.cityLabel.AutoSize = true;
            this.cityLabel.Location = new System.Drawing.Point(48, 93);
            this.cityLabel.Name = "cityLabel";
            this.cityLabel.Size = new System.Drawing.Size(27, 13);
            this.cityLabel.TabIndex = 7;
            this.cityLabel.Text = "City:";
            // 
            // stateLabel
            // 
            this.stateLabel.AutoSize = true;
            this.stateLabel.Location = new System.Drawing.Point(40, 119);
            this.stateLabel.Name = "stateLabel";
            this.stateLabel.Size = new System.Drawing.Size(35, 13);
            this.stateLabel.TabIndex = 8;
            this.stateLabel.Text = "State:";
            // 
            // zipLabel
            // 
            this.zipLabel.AutoSize = true;
            this.zipLabel.Location = new System.Drawing.Point(48, 147);
            this.zipLabel.Name = "zipLabel";
            this.zipLabel.Size = new System.Drawing.Size(25, 13);
            this.zipLabel.TabIndex = 9;
            this.zipLabel.Text = "Zip:";
            // 
            // zipCodeText
            // 
            this.zipCodeText.Location = new System.Drawing.Point(81, 147);
            this.zipCodeText.Name = "zipCodeText";
            this.zipCodeText.Size = new System.Drawing.Size(144, 20);
            this.zipCodeText.TabIndex = 5;
            this.zipCodeText.Validating += new System.ComponentModel.CancelEventHandler(this.zipCodeText_Validating);
            this.zipCodeText.Validated += new System.EventHandler(this.zipCodeText_Validated);
            // 
            // addAddressButton
            // 
            this.addAddressButton.Location = new System.Drawing.Point(40, 200);
            this.addAddressButton.Name = "addAddressButton";
            this.addAddressButton.Size = new System.Drawing.Size(75, 23);
            this.addAddressButton.TabIndex = 6;
            this.addAddressButton.Text = "Add";
            this.addAddressButton.UseVisualStyleBackColor = true;
            this.addAddressButton.Click += new System.EventHandler(this.addAddressButton_Click);
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(150, 200);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 7;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelButton_MouseDown);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // errorProvider4
            // 
            this.errorProvider4.ContainerControl = this;
            // 
            // errorProvider5
            // 
            this.errorProvider5.ContainerControl = this;
            // 
            // AddressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(328, 251);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.addAddressButton);
            this.Controls.Add(this.zipCodeText);
            this.Controls.Add(this.zipLabel);
            this.Controls.Add(this.stateLabel);
            this.Controls.Add(this.cityLabel);
            this.Controls.Add(this.addressLabel);
            this.Controls.Add(this.nameLabel);
            this.Controls.Add(this.stateComboBox1);
            this.Controls.Add(this.cityText);
            this.Controls.Add(this.customerOptionalText);
            this.Controls.Add(this.customerAddressText);
            this.Controls.Add(this.customerNameText);
            this.Name = "AddressForm";
            this.Text = "AddressForm";
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider5)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox customerNameText;
        private System.Windows.Forms.TextBox customerAddressText;
        private System.Windows.Forms.TextBox customerOptionalText;
        private System.Windows.Forms.TextBox cityText;
        private System.Windows.Forms.ComboBox stateComboBox1;
        private System.Windows.Forms.Label nameLabel;
        private System.Windows.Forms.Label addressLabel;
        private System.Windows.Forms.Label cityLabel;
        private System.Windows.Forms.Label stateLabel;
        private System.Windows.Forms.Label zipLabel;
        private System.Windows.Forms.TextBox zipCodeText;
        private System.Windows.Forms.Button addAddressButton;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
        private System.Windows.Forms.ErrorProvider errorProvider4;
        private System.Windows.Forms.ErrorProvider errorProvider5;
    }
}