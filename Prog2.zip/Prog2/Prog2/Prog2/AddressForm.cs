﻿//this form's class validates the information added to the pop-up dialog box, and if the validation passes then a new address is added to the addresslist. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class AddressForm : Form
    {
        //precondition: none
        //postcondition: the form's GUI display is displayed
        public AddressForm()
        {
            InitializeComponent();
        }

        //precondition: none
        //postcondition: the text in the name field has been returned
        internal String CustomerName
        {
            get
            {
                return customerNameText.Text;
            }
            set
            {
                customerNameText.Text = value;
            }
        }
        //precondition: none
        //postcondition: the text in the first address field has been returned
        internal String CustomerAddress
        {
            get
            {
                return customerAddressText.Text;
            }
            set
            {
                customerAddressText.Text = value;
            }
        }
        //precondition: none
        //postcondition: the text in the second address field has been returned
        internal String CustomerAddress2
        {
            get
            {
                return customerOptionalText.Text;
            }
            set
            {
                customerOptionalText.Text = value;
            }
        }
        //precondition: none
        //postcondition: the text in the city field has been returned
        internal String City
        {
            get
            {
                return cityText.Text;
            }
            set
            {
                cityText.Text = value;
            }
        }
        //precondition: none
        //postcondition: the selectedindex of the drop down list has been returned 
        internal String stateComboBox
        {
            get
            {
                return stateComboBox1.Text;
            }
            set
            {
                stateComboBox1.Text = value;
            }
        }
        //precondition: none
        //postcondition: the text in the zipcode field has been returned
        internal string ZipCode
        {
            get
            {
             
                return zipCodeText.Text; //return input
            }
            set
            {
              
                zipCodeText.Text= value;
            }
        }
    
        //precondition: attempting to change focus from customerName
        //postcondition: if selection is invalid, an error provider is shown
        private void customerNameText_Validating(object sender, CancelEventArgs e)
        {
           
            if (string.IsNullOrEmpty(customerNameText.Text))
            {
                e.Cancel = true; //will not proceed to validated event
                errorProvider1.SetError(customerNameText, "Must provide Name"); //set an error
               
            }
          
        }
        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void customerNameText_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(customerNameText, ""); //clear error provider
        }
        //precondition: attempting to change focus from customerAddress
        //postcondition: if selection is invalid, an error provider is shown
        private void customerAddressText_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(customerAddressText.Text)) //validation for if there is any input
            {
                e.Cancel = true; //stops focus from changing
                errorProvider2.SetError(customerAddressText, "Must provide an Address"); //sets an error provider
               
            }
        }
        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void customerAddressText_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(customerAddressText, ""); //clear error provider
        }
        //precondition: attempting to change focus from cityText
        //postcondition: if selection is invalid, an error provider is shown
        private void cityText_Validating(object sender, CancelEventArgs e)
        {
            if(string.IsNullOrEmpty(cityText.Text)) //validation for input 
            {
                e.Cancel = true; //stops focus from changing
                errorProvider3.SetError(cityText, "Must provide a City name"); //sets an error provider
               
            }
        }
        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void cityText_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(cityText, ""); //clear error provider
        }
        //precondition: attempting to change focus from stateComboBox
        //postcondition: if selection is invalid, an error provider is shown
        private void stateComboBox1_Validating(object sender, CancelEventArgs e)
        {
            if (stateComboBox1.SelectedIndex < 0) //validation something is selected
            {
                e.Cancel = true;
                errorProvider5.SetError(stateComboBox1, "Pick a state from the drop down list"); //sets an error provider
            }
            
        }
        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void stateComboBox1_Validated(object sender, EventArgs e)
        {
            errorProvider5.SetError(stateComboBox1, "");//clear error message
        }
        //precondition: attempting to change focus from zipCodeText
        //postcondition: if selection is invalid, an error provider is shown
        private void zipCodeText_Validating(object sender, CancelEventArgs e)
        {
            int number; //variable to hold number for validation
            if (!int.TryParse(zipCodeText.Text, out number)) //validation that input is a number
            {
                e.Cancel = true; //stops focus from changing
                errorProvider4.SetError(zipCodeText, "Enter a valid zip code"); //sets an error provider
            }
            else
            
                if (number < 0) //validates for non-negative integers
                    errorProvider4.SetError(zipCodeText, "Enter a non-negative integer"); //sets error provider
            
            else
                
                if (zipCodeText.TextLength != 5) //sets for correct length for zipcode
                    errorProvider4.SetError(zipCodeText, "Enter a valid zip code"); //sets an error provider

           
        }

        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void zipCodeText_Validated(object sender, EventArgs e)
        {
            errorProvider4.SetError(zipCodeText, ""); //clear error provider
        }

  
        //precondition: cancel button is pressed
        //postcondition: form closes and dialog result is cancel
        private void cancelButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                this.DialogResult = DialogResult.Cancel;
        }
        //precondition: add button is clicked
        //postcondition: if fields are invalid, give error provider, otherwise add the address to the address list
        private void addAddressButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren()) //validation
                this.DialogResult = DialogResult.OK; //closes form and adds the address to the address list
        }
    }
    }

