﻿namespace UPVApp
{
    partial class LetterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.costTextBox = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.addLetterButton = new System.Windows.Forms.Button();
            this.cancelLetterButton = new System.Windows.Forms.Button();
            this.originComboBox = new System.Windows.Forms.ComboBox();
            this.destComboBox = new System.Windows.Forms.ComboBox();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // costTextBox
            // 
            this.costTextBox.Location = new System.Drawing.Point(166, 83);
            this.costTextBox.Name = "costTextBox";
            this.costTextBox.Size = new System.Drawing.Size(100, 20);
            this.costTextBox.TabIndex = 3;
            this.costTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.costTextBox_Validating);
            this.costTextBox.Validated += new System.EventHandler(this.costTextBox_Validated);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(86, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "Origin";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(86, 56);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(60, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Destination";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(86, 83);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(28, 13);
            this.label3.TabIndex = 5;
            this.label3.Text = "Cost";
            // 
            // addLetterButton
            // 
            this.addLetterButton.Location = new System.Drawing.Point(127, 143);
            this.addLetterButton.Name = "addLetterButton";
            this.addLetterButton.Size = new System.Drawing.Size(75, 23);
            this.addLetterButton.TabIndex = 4;
            this.addLetterButton.Text = "Add";
            this.addLetterButton.UseVisualStyleBackColor = true;
            this.addLetterButton.Click += new System.EventHandler(this.addLetterButton_Click);
            // 
            // cancelLetterButton
            // 
            this.cancelLetterButton.Location = new System.Drawing.Point(226, 143);
            this.cancelLetterButton.Name = "cancelLetterButton";
            this.cancelLetterButton.Size = new System.Drawing.Size(75, 23);
            this.cancelLetterButton.TabIndex = 5;
            this.cancelLetterButton.Text = "Cancel";
            this.cancelLetterButton.UseVisualStyleBackColor = true;
            this.cancelLetterButton.MouseDown += new System.Windows.Forms.MouseEventHandler(this.cancelLetterButton_MouseDown);
            // 
            // originComboBox
            // 
            this.originComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.originComboBox.FormattingEnabled = true;
            this.originComboBox.Location = new System.Drawing.Point(166, 29);
            this.originComboBox.Name = "originComboBox";
            this.originComboBox.Size = new System.Drawing.Size(121, 21);
            this.originComboBox.TabIndex = 1;
            this.originComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.originComboBox_Validating);
            this.originComboBox.Validated += new System.EventHandler(this.originComboBox_Validated);
            // 
            // destComboBox
            // 
            this.destComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.destComboBox.FormattingEnabled = true;
            this.destComboBox.Location = new System.Drawing.Point(166, 56);
            this.destComboBox.Name = "destComboBox";
            this.destComboBox.Size = new System.Drawing.Size(121, 21);
            this.destComboBox.TabIndex = 2;
            this.destComboBox.Validating += new System.ComponentModel.CancelEventHandler(this.destComboBox_Validating);
            this.destComboBox.Validated += new System.EventHandler(this.destComboBox_Validated);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // LetterForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(407, 261);
            this.Controls.Add(this.destComboBox);
            this.Controls.Add(this.originComboBox);
            this.Controls.Add(this.cancelLetterButton);
            this.Controls.Add(this.addLetterButton);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.costTextBox);
            this.Name = "LetterForm";
            this.Text = "LetterForm";
            this.Load += new System.EventHandler(this.LetterForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox costTextBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button addLetterButton;
        private System.Windows.Forms.Button cancelLetterButton;
        private System.Windows.Forms.ComboBox originComboBox;
        private System.Windows.Forms.ComboBox destComboBox;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}