﻿//C6003
//CIS 200-01
//Program 2
//this is the test form for the application. This form holds test data for the program as well as the events for the menu items on the form. This form projects all the information provided and input into the form 
//into the GUI. This application runs based on three different input forms. One takes user input to display dialog boxes and lists of parcels and addresses, and the other two take user input for creating a new address
//and sending a letter. 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class Prog2Form : Form
    {
        private UserParcelView upv; //The UserParcelView

        //precondition: none
        //postcondition: The form's GUI is prepared for display with dummy data for items and patrons added to the lists
        public Prog2Form()
        {
            
            InitializeComponent();
            upv = new UserParcelView(); //Create new UserParcelView

            //Test Data
            upv.AddAddress("William Brown","320 Sunshine Rd","Apt 45", "Harrodsburg", "KY", 40330 );
            upv.AddAddress("Sarah Sanderson", "420 Sanders Rd", "", "Lexington", "KY", 40308);
            upv.AddAddress("Bob Barker", "799 RoadIsRight Ln", "", "Hollywood", "CA", 10012);
            upv.AddAddress("Dirik Johnson", "920 Richard Rd", "Suite 101", "Inglewood", "CA", 10012);
            upv.AddAddress("Sean Connery", "1909 Bangers Ln", "", "Hollywood", "CA", 10014);
            upv.AddAddress("Ted Grunchy", "606 Bad Mood Alley", "", "Grouchy", "TN", 30129);
            upv.AddAddress("Bob Salad", "908 Bridges Ln", "Apt 401", "Bringham", "KY", 40392);
            //Parcel Data
            upv.AddLetter(upv.AddressAt(0), upv.AddressAt(3), 3.95M);
            upv.AddLetter(upv.AddressAt(2), upv.AddressAt(4), 4.95M);
            upv.AddGroundPackage(upv.AddressAt(5), upv.AddressAt(1), 23, 12, 67, 45);
            upv.AddNextDayAirPackage(upv.AddressAt(6), upv.AddressAt(3), 55, 60, 40, 78, 6.75M);
            upv.AddNextDayAirPackage(upv.AddressAt(4), upv.AddressAt(3), 43, 12, 54, 65, 9.75M);
            upv.AddTwoDayAirPackage(upv.AddressAt(5), upv.AddressAt(2), 45, 89, 23, 65, TwoDayAirPackage.Delivery.Early);
            upv.AddTwoDayAirPackage(upv.AddressAt(3), upv.AddressAt(2), 65, 24, 75, 45, TwoDayAirPackage.Delivery.Saver);

        }
        
        //precondition: File clicked, About menu item clicked
        //postcondition: Information about student programmer displayed in a dialog box
        private void abouttoolStripMenuItem3_Click(object sender, EventArgs e)
        {
            MessageBox.Show(String.Format("Program 2:{0} C6003{0} CIS 200-01{0} 11/1/2016", Environment.NewLine));
        }

        //precondition:File clicked, Exit menu item clicked
        //postcondition: the application is closed
        private void exitToolStripMenuItem4_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        //precondition: Report clicked, list Addresses clicked
        //postcondition: The list of addresses is displayed in the outputTextBox 
        private void listAddressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            StringBuilder result = new StringBuilder(); 
            List<Address> address; //list of addresses
            address = upv.AddressList;
            foreach(Address a in address)
            {
                result.Append(a.ToString());
                result.Append(System.Environment.NewLine);
                result.Append(System.Environment.NewLine);
            }
            outputTextBox.Text = result.ToString();

            
        }
        //precondition: Report clicked, list Parcel clicked
        //postcondition: The list of parcels is displayed in the outputTextBox
        private void listParcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            decimal totalCost = 0M; //variable to hold calculated cost
            StringBuilder result = new StringBuilder();
            List<Parcel> parcel; //list of parcels
            parcel = upv.ParcelList;
            foreach (Parcel p in parcel)
            {
                result.Append(p.ToString());
                result.Append(System.Environment.NewLine);
                result.Append(System.Environment.NewLine);
                totalCost += p.CalcCost();
            }
            outputTextBox.Text = result.ToString();
            outputTextBox.Text += "Total Cost:" + "" + totalCost.ToString("c");
        }
        //precondition: Insert clicked, Address clicked
        //postcondition: The Address dialog box is displayed, allowing data entry, then adding an address to the list of addresses
        private void addressToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AddressForm addressForm = new AddressForm(); //address form dialog box
            DialogResult result = addressForm.ShowDialog();
            if (result == DialogResult.OK) //validation
            {
                //Send Address to the address list
                upv.AddAddress(addressForm.CustomerName, addressForm.CustomerAddress, addressForm.CustomerAddress2, addressForm.City,
                    addressForm.stateComboBox, Convert.ToInt32(addressForm.ZipCode));
            }
           

            
        }
        //precondition: Insert clicked, Letter clicked
        //postcondition: The letter dialog box is displayed, allowing data entry, then adding a letter to the list of parcels
        private void letterToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LetterForm letterForm = new LetterForm(upv.AddressList); //new letter 
            DialogResult result = letterForm.ShowDialog();
            if (result == DialogResult.OK) //validation
            {
                //add letter to the list of parcels
                upv.AddLetter(upv.AddressAt(letterForm.OriginAddress), upv.AddressAt(letterForm.DestinationAddress), decimal.Parse(letterForm.FixedCost));
            }
                
        }
                
                   
            }
        
        }

       
    

