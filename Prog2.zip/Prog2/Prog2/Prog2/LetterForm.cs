﻿//this form's class validates that there have been selections 
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace UPVApp
{
    public partial class LetterForm : Form
    {
        private List<Address> listofAddresses; //creates a list of addresses
        //precondition: none
        //postcondition: The list of addresses are used to populate the drop down lists
        public LetterForm(List<Address> addresses)
        {
            InitializeComponent();
            listofAddresses = addresses;

        }
        //precondition: none
        //postcondition: The list of addresses are added to each of the combo boxes
        private void LetterForm_Load(object sender, EventArgs e)
        {
            foreach(Address a in listofAddresses)
            {
                originComboBox.Items.Add(a.Name);
                destComboBox.Items.Add(a.Name);
            }
        }
        //precondition: none
        //postcondition: the index of the comboBox's selectedindex is returned
        internal int OriginAddress
        {
            get
            {
                return originComboBox.SelectedIndex;
            }
            set
            {
                originComboBox.SelectedIndex = value;
            }
        }
        //precondition: none
        //postcondition: the index of the comboBox's selectedindex is returned
        internal int DestinationAddress
        {
            get
            {
                return destComboBox.SelectedIndex;
            }
            set
            {
                destComboBox.SelectedIndex = value;
            }
        }
        //precondition: none
        //postcondition: the text of the costTextBox is returned
        internal string FixedCost
        {
            get
            {
                return costTextBox.Text;
            }
            set
            {
                costTextBox.Text = value;
            }
        }
        //precondition: attempting to change focus from originComboBox
        //postcondition: if selection is invalid, an error provider is shown
        private void originComboBox_Validating(object sender, CancelEventArgs e)
        {
             //stops focus from shifting
            if (originComboBox.SelectedIndex < 0) //validation
                e.Cancel = true;
                errorProvider1.SetError(originComboBox, "Please Select an Origin Address"); //sets an error message
        }
        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void originComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(originComboBox, ""); //clear error message
        }
        //precondition: attempting to change focus from destComboBox
        //postcondition: if selection is invalid, an error provider is shown
        private void destComboBox_Validating(object sender, CancelEventArgs e)
        {
          
            if (destComboBox.SelectedIndex < 0 || destComboBox.SelectedIndex == originComboBox.SelectedIndex) //validation
                e.Cancel = true; //stops focus from shifting
                errorProvider2.SetError(originComboBox, "Please Choose A Valid Address"); //set error message
        }
        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void destComboBox_Validated(object sender, EventArgs e)
        {
            errorProvider2.SetError(destComboBox, ""); //clear error message
        }
        //precondition: attempting to change focus from costTextBox
        //postcondition: if selection is invalid, an error provider is shown
        private void costTextBox_Validating(object sender, CancelEventArgs e)
        {
            double number; //variable to hold parsed input from cost textbox
             //stops focus from shifting
            if ((string.IsNullOrEmpty(costTextBox.Text)) || (!double.TryParse(costTextBox.Text, out number)))//validation
                e.Cancel = true;
                errorProvider3.SetError(costTextBox, "Enter a valid cost amount"); //set error message
        }
        //precondition: input validated
        //postcondition: error provider clear and focus moves
        private void costTextBox_Validated(object sender, EventArgs e)
        {
            errorProvider3.SetError(costTextBox, "");//clear error message
        }

        
        //precondition: cancel button has been pressed
        //postcondition: if left click, cancel and clost the dialog box
        private void cancelLetterButton_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left) //validates left click
                this.DialogResult = DialogResult.Cancel; //sets dialog result to cancel
        }
        //precondition: add button has been clicked
        //postcondition: if fields are invalid, give error provider, otherwise add letter to the parcels list
        private void addLetterButton_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren()) //validation
            {
                this.DialogResult = DialogResult.OK; //closes form and adds letter to the parcel list
            }
            
        }
    }
}
