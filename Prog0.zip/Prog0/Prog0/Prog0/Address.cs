﻿//Address class describing Name, Addresses, City, State, and ZipCode information
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public class Address
    {
        private string _name;                           //Name of the person listed
        private string _addressOne;                     //Address One of listed person
        private string _addressTwo;                     //Address Two of listed person
        private string _city;                           //City Name of listed person
        private string _state;                          //State Name of listed person
        private int _zipCode;                           //ZipCode of listed person

        const int lowerLimit = 00000;                   //constant holding lower limit of possible zip codes
        const int upperLimit = 99999;                   //constant holding upper limit of possible zip codes

        //Precondition: None
        //Postcondition: the address has been initialized with the specified values for name, address one, address two, 
        //               city, state, and zipcode.
        public Address(string theName, string addressOne, string addressTwo, string city, string state, int zipCode)
        {
            Name = theName;                         
            Address1 = addressOne;               
            Address2 = addressTwo;               
            City = city;                       
            State = state;                     
            Zip = zipCode;                     
        }

        public string Name
        {
            //Precondition: none
            //Postcondition: The name has been set to a specified value
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }

        public string Address1
        {
            //Precondition: none
            //Postcondition: The first address has been set to a specified value
            get
            {
                return _addressOne;
            }
            set
            {
                _addressOne = value;
            }
        }

        public string Address2
        {
            //Precondition: none
            //Postcondition: The second address has been set to a specified value
            get
            {
                return _addressTwo;
            }
            set
            {
                _addressTwo = value;
            }
        }
        public string City
        {
            //Precondition: none
            //Postcondition: The city has been set to a specified value
            get
            {
                return _city;
            }
            set
            {
                _city = value;
            }
        }
        public string State
        {
            //Precondition: none
            //Postcondition: The state has been set to a specified value
            get
            {
                return _state;
            }
            set
            {
                _state = value;
            }
        }
        public int Zip
        {
            //Precondition: the zipcode is a non-negative integer number <= 99999
            //Postcondition: the zipcode has been set to a specified value
            get
            {
                return _zipCode;
            }
            set
            {
                if(value >= lowerLimit && value <= upperLimit)
                _zipCode = value;                
            }
        }
        //Precondition: none
        //Postcondition: A string is returned presenting the Address information on 4 separate lines
        public override string ToString()
        {
            

            return String.Format("Name:{0}\nAddress One: {1}\nAddress Two: {2}\n{3}, {4} {5:d5}",Name, Address1, Address2, City, State, Zip);
            
        }

    }
}
