﻿//abstract Parcel class to hold abstract method CalcCost intialized in Letter class. 
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prog0
{
    public abstract class Parcel 
    {
              
        //Precondition: none
        //Postcondition: the Parcel has been initialized with a destination address and an origin address
        public Parcel(Address destination, Address origin)
        {
            OriginAddress = origin;
            DestinationAddress = destination;
        }

        public Address OriginAddress
        {
            //Precondition: none
            //Postcondition: none
            get;
            set;
            
            
        }

        public Address DestinationAddress
        {
            //Precondition: none
            //Postcondition: none
            get;
            set;
        }

        //abstract method CalcCost to be initialized in Letter class
        public abstract decimal CalcCost();

        //Precondition: none
        //Postcondition: returns a string with origin address and destination address
        public override string ToString()
        {            
            return String.Format("\nOrigin Address:\n{0}\n\nDestination Address: \n{1}", OriginAddress, DestinationAddress);
        }

        
        
    }

   
}
